# Ammare.3D keychain website — beginner guide

Website statik, Bahasa Melayu, mobile-first. Hosting yang dicadangkan: GitHub Pages (percuma untuk repository public). Tiada order database/server dalam versi pertama; tempahan dihantar ke WhatsApp.

## Folder
- `index.html` — semua tab/borang.
- `style.css` — design, mobile layout, light/dark mode.
- `config.js` — semua setting harga, nombor, warna, produk, galeri dan ulasan.
- `app.js` — fungsi troli, pengiraan harga, WhatsApp dan integrasi worker.
- `scad/keychain.scad` — contoh parametric model.
- `wasm/scad-worker.js` — worker untuk memanggil OpenSCAD WASM.
- `assets/images/` — masukkan foto produk/review di sini.

## Quick start
1. Upload semua fail/folder ke repository GitHub.
2. Pastikan `index.html`, `app.js`, `config.js` dan `style.css` berada di root (bukan dalam subfolder).
3. GitHub repository → Settings → Pages → Build and deployment → Deploy from a branch → `main` → `/(root)` → Save.
4. Tunggu beberapa minit dan tekan Visit site.

## Penting tentang OpenSCAD WASM
Website tempahan/WhatsApp berfungsi tanpa WASM. Bahagian WASM dimatikan secara default (`openscadEnabled: false`) supaya website tidak rosak jika enjin belum dipasang.

Official projects:
- https://github.com/openscad/openscad-wasm
- https://github.com/openscad/openscad-playground

`openscad-wasm` memberi modul headless dan contoh API, tetapi ia bukan satu fail CDN mudah. Anda perlu mendapatkan build yang serasi dan meletakkan output browser yang diperlukan dalam folder `wasm/`, sekurang-kurangnya `openscad.js` dan `openscad.wasm` (sesetengah build perlukan data/fonts/libraries tambahan). Ikut arahan versi projek yang anda gunakan. Jangan copy fail daripada build Node sahaja; perlukan build browser/Emscripten.

### Uji model dahulu
1. Buka `scad/keychain.scad` dalam aplikasi desktop OpenSCAD.
2. Tekan F5 (preview), kemudian F6 (render).
3. Cuba tukar `label_text`, `part="base"` dan `part="text"`.
4. Pastikan tiada error dan kedua-dua bahagian berasingan boleh dicetak.
5. Pastikan font yang disebut tersedia. Jika tidak, tukar kepada font yang dipasang atau buang parameter `font`.
6. Untuk model sendiri, pastikan ia menerima parameter `label_text` dan `part`. Dalam model anda, gunakan `part=="base"` untuk geometri tapak sahaja dan `part=="text"` untuk geometri teks sahaja. Jika model guna nama parameter lain, ubah `params` dalam `wasm/scad-worker.js`.

### Cara parameter dihantar
Worker membina teks seperti:
`label_text = "AMMAR"; keychain_type = "nama"; part="base";`
kemudian menambah kandungan fail `.scad` dan menjalankan OpenSCAD dalam Worker. Worker eksport dua STL berasingan. STL sendiri tidak menyimpan warna bahan; aplikasi slicer/preview perlu menetapkan warna berasingan untuk setiap bahagian. Dalam versi asas ini, muat turun STL disediakan tetapi preview WASM penuh dan multi-colour viewport belum disambungkan. Preview atas borang ialah mock-up visual, bukan mesh sebenar. Ini perlu dinyatakan dengan jujur kepada pelanggan.

**Jangan aktifkan `openscadEnabled: true` sehingga anda telah meletakkan dan menguji fail WASM yang betul.** API builds boleh berbeza; jika build yang anda ambil tidak serasi dengan ES module import ini, gunakan contoh `example/` daripada versi repository yang sama untuk memadankan loader.

### Limitasi
- Browser OpenSCAD ialah port terhad; model berat boleh lambat, terutama telefon.
- Fail `.scad` yang `include`/`use` fail lain perlu semua dependency disalin ke laluan yang betul.
- Font, SVG import dan library tambahan memerlukan persediaan khusus.
- Jangan benarkan pengguna memasukkan kod OpenSCAD bebas untuk dijalankan; hanya masukkan teks pelanggan yang telah di-escape seperti worker ini.
- STL dua warna dicetak sebagai dua bahagian/filamen berasingan; periksa fit dan overlap dalam slicer sebelum cetak.

## Ubah setting
Edit `config.js`:
- `whatsapp`: nombor dalam format antarabangsa tanpa `+`.
- `regularPrice`, `bulkPrice`, `bulkQuantity`.
- `colors`: tambah atau buang warna; guna nama dan kod HEX.
- `products`: tambah object produk baharu, dan pastikan `id` unik.
- `gallery` dan `reviews`: letak nama fail gambar yang anda upload.

## Tambah gambar
Upload JPG/PNG ke `assets/images/`. Tukar path dalam `config.js`, contoh:
`{ image: "assets/images/keychain-ammar.jpg", title: "Keychain Ammar", note: "Tapak biru pekat, teks putih" }`

## Deposit / harga
Bulk price dikira berdasarkan jumlah kuantiti keseluruhan troli. Deposit 50% automatik dipaparkan untuk jumlah bulk. Semua tempahan custom pula perlu deposit 50% — website versi awal menyatakan syarat ini, tetapi jumlah deposit custom disahkan manual melalui WhatsApp.

## Order status — fasa 2 (percuma)
Paling mudah: Google Sheets + Google Apps Script Web App. Buat Sheet dengan columns `OrderNo`, `CustomerName`, `Status`; statuses: `Diterima`, `Dalam proses`, `Siap`, `Dah COD`. Apps Script boleh publish sebagai Web App dan website query status melalui endpoint. Ini memerlukan satu langkah setup dan sedikit kod tambahan; jangan simpan alamat penuh/nombor sensitif dalam sheet public. Alternatif paling mudah tanpa backend: admin beri status manual melalui WhatsApp.

## Email notification — pilihan
Google Forms boleh hantar notifikasi kepada pemilik apabila borang dihantar (atau add-on). Namun pesanan website sekarang terus ke WhatsApp, jadi Google Forms tidak automatik mengetahui pesanan. Untuk e-mel automatik, fasa 2 boleh menghantar salinan pesanan melalui Apps Script atau gunakan Google Form sebagai langkah tambahan.

## Keselamatan & privasi
Repository GitHub Pages Free biasanya public. Jangan upload maklumat pelanggan, order sebenar, token, password atau data peribadi. Maklumat pelanggan dalam borang hanya dihantar melalui WhatsApp dan tidak disimpan oleh website ini.
