// Muatkan konfigurasi sebelum app.js dalam HTML (lihat nota di bawah).
const CFG = window.STORE_CONFIG;
const $ = (id) => document.getElementById(id);
let cart = [];
let selectedTab = "tempah";
const money = (n) => "RM" + Number(n).toFixed(2);
const esc = (s) => String(s).replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
const wa = (text) => `https://wa.me/${CFG.whatsapp}?text=${encodeURIComponent(text)}`;

function init() {
  // Select fields
  $("product").innerHTML = CFG.products.map(p => `<option value="${esc(p.id)}">${esc(p.name)}</option>`).join("");
  const options = CFG.colors.map(c => `<option value="${esc(c.name)}">${esc(c.name)}</option>`).join("");
  $("baseColor").innerHTML = options; $("textColor").innerHTML = options;
  $("baseColor").value = "Biru pekat"; $("textColor").value = "Putih";
  $("swatches").innerHTML = CFG.colors.map(c => `<span title="${esc(c.name)}" class="swatch" style="background:${c.hex}"></span>`).join("");
  $("gallery").innerHTML = CFG.gallery.map(g => `<article class="galleryitem"><img src="${esc(g.image)}" alt="${esc(g.title)}" loading="lazy" onerror="this.style.display='none';this.nextElementSibling.style.display='grid'"><div class="imagefallback">📸<span>${esc(g.title)}</span><small>Tambah gambar di assets/images</small></div><div class="gallerycaption"><strong>${esc(g.title)}</strong><small>${esc(g.note)}</small></div></article>`).join("");
  $("reviews").innerHTML = CFG.reviews.map(r => `<article class="review"><img src="${esc(r.image)}" alt="${esc(r.title)}" loading="lazy" onerror="this.style.display='none';this.nextElementSibling.style.display='grid'"><div class="imagefallback">💬<span>${esc(r.title)}</span><small>Tambah screenshot di assets/images</small></div><p>${esc(r.text)}</p></article>`).join("");
  $("regularTable").textContent = money(CFG.regularPrice);
  $("bulkDisplay").innerHTML = `${money(CFG.bulkPrice)} <small>/ pcs</small>`;
  $("bulkTable").textContent = money(CFG.bulkPrice);
  $("bulkQtyTable").textContent = `${CFG.bulkQuantity} pcs ke atas`;
  $("year").textContent = new Date().getFullYear();
  $("floatWA").href = wa("Hai Ammare.3D! Saya nak tanya tentang keychain 😊");
  document.querySelectorAll(".tab").forEach(b => b.addEventListener("click", () => showTab(b.dataset.tab)));
  $("product").addEventListener("change", updateProduct);
  ["itemText","baseColor","textColor","size"].forEach(id => $(id).addEventListener("input", updatePreview));
  $("addBtn").addEventListener("click", addItem);
  $("sendOrder").addEventListener("click", sendOrder);
  $("sendCustom").addEventListener("click", sendCustom);
  $("themeBtn").addEventListener("click", () => { document.body.classList.toggle("dark"); $("themeBtn").textContent = document.body.classList.contains("dark") ? "☀" : "☾"; });
  $("renderBtn").addEventListener("click", runOpenSCAD);
  updateProduct(); updatePreview(); renderCart();
}
function showTab(tab) {
  selectedTab = tab;
  document.querySelectorAll(".tab").forEach(b => b.classList.toggle("active", b.dataset.tab === tab));
  document.querySelectorAll(".panel").forEach(p => p.classList.toggle("active", p.id === tab));
  window.scrollTo({top: document.querySelector(".tabs").offsetTop - 8, behavior:"smooth"});
}
function updateProduct() {
  const p = CFG.products.find(p => p.id === $("product").value) || CFG.products[0];
  $("textLabel").textContent = p.label; $("itemText").placeholder = p.placeholder;
  $("itemText").maxLength = CFG.maxTextLength; updatePreview();
}
function colorObj(name) { return CFG.colors.find(c => c.name === name) || CFG.colors[0]; }
function updatePreview() {
  const base = colorObj($("baseColor").value), text = colorObj($("textColor").value);
  $("previewText").textContent = $("itemText").value.trim() || "NAMA";
  $("previewText").style.color = text.hex;
  $("previewText").style.background = base.hex;
  $("previewText").style.borderColor = text.hex;
  $("preview").style.setProperty("--base", base.hex);
  const same = base.name === text.name;
  $("colorWarning").hidden = !same;
  $("addBtn").disabled = same;
  $("renderBtn").disabled = same || !($("itemText").value.trim());
}
function priceForQty(qty) { return qty >= CFG.bulkQuantity ? CFG.bulkPrice : CFG.regularPrice; }
function totalQty() { return cart.reduce((sum, item) => sum + item.qty, 0); }
function totalPrice() {
  // Bulk threshold is applied to total quantity across all products.
  const q = totalQty(); return q >= CFG.bulkQuantity ? q * CFG.bulkPrice : q * CFG.regularPrice;
}
function addItem() {
  const text = $("itemText").value.trim(), base = $("baseColor").value, color = $("textColor").value;
  const qty = Math.max(1, Math.min(100, parseInt($("qty").value,10) || 1));
  if (!text) { alert("Masukkan nama atau nombor plat dahulu ya 😊"); $("itemText").focus(); return; }
  if (base === color) { alert("Warna tapak dan teks mesti berbeza."); return; }
  const product = CFG.products.find(p => p.id === $("product").value);
  cart.push({ id:Date.now()+Math.random(), product:product.name, productId:product.id, text, base, color, qty, size:$("size").value });
  renderCart();
}
function removeItem(id) { cart = cart.filter(i => i.id !== id); renderCart(); }
function renderCart() {
  $("cartCount").textContent = `${totalQty()} item`;
  if (!cart.length) $("cartItems").innerHTML = `<div class="empty">Troli masih kosong. Jom pilih keychain! ✨</div>`;
  else $("cartItems").innerHTML = cart.map(i => `<div class="cartitem"><div><strong>${esc(i.product)} — ${esc(i.text)}</strong><small>Tapak: ${esc(i.base)} · Teks: ${esc(i.color)} · ${esc(i.size)} · ${i.qty} pcs</small></div><strong>${money(i.qty * priceForQty(i.qty))}</strong><button class="remove" data-remove="${i.id}" aria-label="Buang item">×</button></div>`).join("");
  $("cartItems").querySelectorAll("[data-remove]").forEach(b => b.addEventListener("click", () => removeItem(Number(b.dataset.remove))));
  $("total").textContent = money(totalPrice());
  const deposit = totalQty() >= CFG.bulkQuantity ? totalPrice()*CFG.depositPercent/100 : 0;
  $("depositNote").textContent = deposit ? `Deposit ${CFG.depositPercent}% diperlukan: ${money(deposit)}. Baki: ${money(totalPrice()-deposit)}.` : "Deposit 50% diperlukan untuk tempahan custom atau jumlah " + CFG.bulkQuantity + " pcs ke atas.";
}
function sendOrder() {
  if (!cart.length) { alert("Troli masih kosong. Tambah keychain dahulu ya 😊"); showTab("tempah"); return; }
  const name = $("customerName").value.trim();
  if (!name) { alert("Masukkan nama anda dahulu."); $("customerName").focus(); return; }
  const delivery = $("delivery").value, area = $("codArea").value.trim() || "Belum ditentukan", day = $("codDay").value.trim() || "Belum ditentukan";
  const lines = cart.map((i,n) => `${n+1}. ${i.product}\n   Teks: ${i.text}\n   Tapak: ${i.base} | Teks warna: ${i.color}\n   Saiz: ${i.size} | Kuantiti: ${i.qty}\n`).join("\n");
  const total = totalPrice(), depositRequired = totalQty() >= CFG.bulkQuantity;
  const message = `Hai ${CFG.businessName}! Saya nak buat tempahan keychain 😊\n\nNAMA: ${name}\n\nITEM:\n${lines}\nJumlah kuantiti: ${totalQty()} pcs\nJumlah anggaran: ${money(total)}\n${depositRequired ? `Deposit ${CFG.depositPercent}%: ${money(total*CFG.depositPercent/100)}\n` : ""}Cara terima: ${delivery}\nKawasan/lokasi: ${area}\nHari pilihan: ${day}\n\nBoleh sahkan tempahan dan masa siap? Terima kasih!`;
  window.open(wa(message), "_blank", "noopener");
}
function sendCustom() {
  const idea = $("customIdea").value.trim(), name = $("customName").value.trim();
  if (!idea || !name) { alert("Isi idea dan nama anda dahulu ya 😊"); return; }
  const msg = `Hai ${CFG.businessName}! Saya nak minta sebut harga custom.\n\nNama: ${name}\nIdea: ${idea}\nSaiz: ${$("customSize").value || "Belum pasti"}\nKuantiti: ${$("customQty").value || "1"}\nBajet: ${$("customBudget").value ? money($("customBudget").value) : "Mohon cadangan"}\n\nSaya akan hantar gambar rujukan dalam chat ini. Terima kasih!`;
  window.open(wa(msg), "_blank", "noopener");
}
async function runOpenSCAD() {
  if (!CFG.openscadEnabled) {
    $("renderMessage").textContent = "Enjin WASM belum dipasang. Ikut panduan README untuk letakkan openscad.js dan openscad.wasm dalam folder wasm/, kemudian tukar openscadEnabled kepada true.";
    return;
  }
  $("renderMessage").textContent = "Sedang jana model… jangan tutup tab ini.";
  $("renderBtn").disabled = true;
  try {
    const worker = new Worker("wasm/scad-worker.js", {type:"module"});
    worker.onmessage = (event) => {
      if (event.data.error) $("renderMessage").textContent = "Ralat OpenSCAD: " + event.data.error;
      else if (event.data.ready) $("renderMessage").textContent = "Model STL berjaya dijana. Fail boleh dimuat turun di bawah.";
      else if (event.data.stl) {
        const blob = new Blob([event.data.stl], {type:"model/stl"});
        const url = URL.createObjectURL(blob);
        const a = document.createElement("a"); a.href = url; a.download = event.data.filename; a.className = "btn secondary"; a.textContent = "Muat turun " + event.data.part.toUpperCase() + " STL"; $("downloads").append(a);
      }
      $("renderBtn").disabled = false; worker.terminate();
    };
    worker.onerror = e => { $("renderMessage").textContent = "Worker gagal dimulakan. Semak fail WASM dan console browser."; $("renderBtn").disabled = false; worker.terminate(); };
    const p = CFG.products.find(p => p.id === $("product").value);
    worker.postMessage({text:$("itemText").value.trim(), product:p.id, base:colorObj($("baseColor").value).hex, textColor:colorObj($("textColor").value).hex, size:$("size").value, scadFile:p.scadFile});
  } catch (e) { $("renderMessage").textContent = "Tidak dapat memulakan OpenSCAD: " + e.message; $("renderBtn").disabled = false; }
}
document.addEventListener("DOMContentLoaded", () => {
  // Load config dynamically so the settings stay in a single file.
  const script = document.createElement("script"); script.src = "config.js";
  script.onload = init; script.onerror = () => alert("config.js tidak dapat dimuat.");
  document.head.appendChild(script);
});