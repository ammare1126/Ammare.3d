/* UBAH SETTINGS DI SINI SAHAJA */
window.STORE_CONFIG = {
  businessName: "Ammare.3D",
  whatsapp: "60178422719", // nombor antarabangsa tanpa + atau ruang
  regularPrice: 5,
  bulkPrice: 4,            // MUDAH DITUKAR selepas harga bulk disahkan
  bulkQuantity: 10,
  depositPercent: 50,
  maxTextLength: 18,
  colors: [
    { name: "Putih", hex: "#F8FAFC" },
    { name: "Hitam", hex: "#202124" },
    { name: "Merah", hex: "#E53935" },
    { name: "Jingga", hex: "#F57C00" },
    { name: "Biru", hex: "#1976D2" },
    { name: "Kuning", hex: "#FDD835" },
    { name: "Purple", hex: "#8E44AD" },
    { name: "Pink", hex: "#F06292" },
    { name: "Biru pekat", hex: "#102A56" },
    { name: "Hijau", hex: "#2E8B57" }
  ],
  products: [
    { id: "nama", name: "Keychain nama", label: "Nama pada keychain", placeholder: "Contoh: AMMAR", scadFile: "scad/keychain.scad" },
    { id: "plate", name: "Keychain no plate", label: "Nombor plat", placeholder: "Contoh: JQA1234", scadFile: "scad/keychain.scad" }
  ],
  gallery: [
    { image: "assets/images/keychain-1.jpg", title: "Keychain nama", note: "Gantikan dengan gambar produk anda" },
    { image: "assets/images/keychain-2.jpg", title: "Keychain dua warna", note: "Gantikan dengan gambar produk anda" },
    { image: "assets/images/keychain-3.jpg", title: "Keychain no plate", note: "Gantikan dengan gambar produk anda" },
    { image: "assets/images/keychain-4.jpg", title: "Tempahan custom", note: "Gantikan dengan gambar produk anda" }
  ],
  reviews: [
    { image: "assets/images/review-1.jpg", title: "Review pelanggan", text: "Letakkan screenshot review sebenar di sini." },
    { image: "assets/images/review-2.jpg", title: "Review pelanggan", text: "Letakkan screenshot review sebenar di sini." }
  ],
  /* Aktifkan selepas fail WASM diletakkan di folder wasm/ */
  openscadEnabled: false
};